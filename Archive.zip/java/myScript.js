<script type="text/javascript" src="java/myScript.js"></script>
